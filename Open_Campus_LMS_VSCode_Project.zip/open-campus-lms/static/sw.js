/* Only versioned, non-sensitive static assets are cached.
   Course files can be downloaded by students for offline access using their browser.
   Pages, grades and private user content are intentionally never cached. */
const CACHE_NAME = 'open-campus-assets-v1';
const ASSETS = ['/static/css/site.css', '/static/js/site.js', '/static/img/favicon.svg'];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS)));
  self.skipWaiting();
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key)))));
  self.clients.claim();
});
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (event.request.method !== 'GET' || url.origin !== self.location.origin || !url.pathname.startsWith('/static/')) return;
  event.respondWith(caches.match(event.request).then(cached => cached || fetch(event.request)));
});
