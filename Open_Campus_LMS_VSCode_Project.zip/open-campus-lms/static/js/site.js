/* Browser enhancements. All critical workflows are server-side and work without JS. */
(() => {
  'use strict';
  const toggle = document.querySelector('#mobile-menu-toggle');
  const menu = document.querySelector('#mobile-nav');
  if (toggle && menu) toggle.addEventListener('click', () => {
    menu.hidden = !menu.hidden;
    toggle.setAttribute('aria-expanded', String(!menu.hidden));
    toggle.textContent = menu.hidden ? '☰' : '✕';
  });
  document.querySelectorAll('.confirm-delete').forEach(form => {
    form.addEventListener('submit', event => {
      if (!window.confirm(form.dataset.confirm || 'Delete this record permanently?')) event.preventDefault();
    });
  });
  // Public seat availability refresh, not a promise of a held reservation.
  const availability = document.querySelector('#availability-count');
  if (availability) {
    const refresh = async () => {
      try {
        const res = await fetch(availability.dataset.url, {cache: 'no-store'});
        if (!res.ok) return;
        const data = await res.json();
        availability.textContent = data.available ? `${data.remaining} places available` : 'Currently full';
      } catch (_) { /* Server-rendered seat count remains visible. */ }
    };
    window.setInterval(refresh, 20000);
  }
  // Cookie manager: current build has no non-essential services. When available,
  // tarteaucitron owns consent; the first-party banner works if the CDN is offline.
  const banner = document.querySelector('#consent-banner');
  const hasCMP = typeof window.tarteaucitron?.init === 'function';
  if (hasCMP) {
    window.tarteaucitron.init({
      privacyUrl: '', bodyPosition: 'bottom', hashtag: '#tarteaucitron',
      cookieName: 'tarteaucitron', orientation: 'bottom', groupServices: false,
      showDetailsOnClick: true, serviceDefaultState: 'wait',
      showAlertSmall: false, cookieslist: false, showIcon: false,
      mandatory: true, mandatoryCta: true, highPrivacy: true,
      acceptAllCta: true, denyAllCta: true, closePopup: false
    });
    if (banner) banner.hidden = true;
  } else {
    const choice = (() => { try { return localStorage.getItem('open-campus-consent'); } catch (_) { return null; }})();
    if (banner && !choice) banner.hidden = false;
  }
  const decide = level => {
    try { localStorage.setItem('open-campus-consent', level); } catch (_) {}
    if (banner) banner.hidden = true;
  };
  document.querySelector('#reject-optional')?.addEventListener('click', () => decide('essential'));
  document.querySelector('#accept-optional')?.addEventListener('click', () => decide('optional'));
  document.querySelector('#privacy-settings')?.addEventListener('click', () => {
    if (hasCMP && window.tarteaucitron.userInterface?.openPanel) window.tarteaucitron.userInterface.openPanel();
    else if (banner) banner.hidden = false;
  });
  // Register offline shell for PWA on localhost/HTTPS; user files remain explicit downloads.
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
    window.addEventListener('load', () => navigator.serviceWorker.register('/static/sw.js', {scope: '/static/'}).catch(() => {}));
  }
})();
