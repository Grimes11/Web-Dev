"""Zero-dependency static checks; runtime integration tests require Django and MongoDB."""
from pathlib import Path
import ast
import unittest

ROOT = Path(__file__).resolve().parents[1]

class ProjectContractTests(unittest.TestCase):
    def test_every_python_file_parses(self):
        for path in ROOT.rglob('*.py'):
            ast.parse(path.read_text(encoding='utf8'), filename=str(path))

    def test_core_documents_covered(self):
        text = (ROOT / 'core/db.py').read_text()
        for name in ('users', 'courses', 'enrolments', 'assignments', 'submissions', 'grades'):
            self.assertIn(f"'{name}'", text)

    def test_every_url_uses_csrf_protected_post(self):
        base = (ROOT/'templates/base.html').read_text()
        self.assertIn('{% csrf_token %}', base)
        self.assertIn('name="password"', (ROOT/'templates/auth.html').read_text())

    def test_local_assets_exist(self):
        for asset in ('css/site.css','js/site.js','img/favicon.svg','manifest.webmanifest','sw.js'):
            self.assertTrue((ROOT/'static'/asset).exists(), asset)

if __name__ == '__main__':
    unittest.main()
