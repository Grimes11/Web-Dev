from functools import wraps
from django.contrib import messages
from django.shortcuts import redirect
from django.http import HttpResponseForbidden
from .db import oid, col

def login_required(view):
    @wraps(view)
    def wrapper(request, *args, **kwargs):
        if not request.user_doc:
            messages.info(request, 'Please sign in to continue.')
            return redirect('login')
        return view(request, *args, **kwargs)
    return wrapper

def roles(*allowed):
    def decorator(view):
        @wraps(view)
        @login_required
        def wrapper(request, *args, **kwargs):
            if request.user_doc.get('role') not in allowed:
                return HttpResponseForbidden('You do not have access to this page.')
            return view(request, *args, **kwargs)
        return wrapper
    return decorator

def manages(request, course):
    user = request.user_doc
    return bool(user and (user['role'] == 'administrator' or (user['role'] == 'lecturer' and str(course.get('lecturer_id')) == user['id'])))

def enrolled(request, course_id):
    if not request.user_doc or request.user_doc.get('role') != 'student':
        return None
    return col('enrolments').find_one({'course_id': oid(course_id), 'student_id': oid(request.user_doc['id']), 'status': 'active'})
