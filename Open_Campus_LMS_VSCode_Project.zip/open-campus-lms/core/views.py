"""Server-rendered LMS workflows. No client-side trust for access, scores or prices."""
import json
import re
import uuid
from datetime import datetime, timedelta, timezone
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from zoneinfo import ZoneInfo
from bson import ObjectId
from django.conf import settings
from django.contrib import messages
from django.contrib.auth.hashers import check_password, make_password
from django.core.cache import cache
from django.core.mail import send_mail
from django.http import FileResponse, Http404, HttpResponseBadRequest, HttpResponseForbidden, JsonResponse
from django.shortcuts import redirect, render
from django.utils.text import get_valid_filename
from django.views.decorators.http import require_GET, require_POST
from pymongo.errors import DuplicateKeyError
from .db import col, oid, get_one, clean, clean_list, now, settings_doc, safe_search, CORE_COLLECTIONS
from .security import login_required, roles, manages, enrolled

MAX_FILE_SIZE = 25 * 1024 * 1024
FILE_TYPES = {'.pdf', '.docx', '.pptx', '.xlsx', '.txt', '.csv', '.png', '.jpg', '.jpeg', '.webp', '.mp4'}


def render_page(request, template, **data):
    data['is_app'] = template in {'dashboard.html', 'learning.html', 'assignment.html', 'quiz.html', 'messages.html', 'lecturer.html', 'course_editor.html', 'material_upload.html', 'assessment_editor.html', 'grade.html', 'control.html', 'admin_users.html', 'admin_user_edit.html', 'admin_settings.html', 'database.html', 'database_record.html'}
    return render(request, template, data)


def money(value):
    return Decimal(str(value or '0')).quantize(Decimal('.01'), rounding=ROUND_HALF_UP)


def public_courses(query=None):
    return clean_list(col('courses').find(query or {'status': 'published'}).sort('created_at', -1))


def occupancy(course_id):
    return col('enrolments').count_documents({'course_id': oid(course_id), 'status': 'active'})


def can_view_course(request, course):
    return course.get('status') == 'published' or manages(request, course)


def course_enriched(course):
    row = clean(course)
    lecturer = col('users').find_one({'_id': course.get('lecturer_id')}, {'name': 1}) if isinstance(course.get('lecturer_id'), ObjectId) else None
    row['lecturer_name'] = lecturer['name'] if lecturer else 'Course team'
    row['enrolled_count'] = occupancy(row['id'])
    row['remaining'] = max(0, int(row.get('capacity', 0)) - row['enrolled_count'])
    row['is_full'] = row['remaining'] == 0
    row['price_display'] = f"{money(row.get('price', 0)):,.0f}"
    return row


def email_notice(subject, text, recipient):
    if recipient:
        send_mail(subject, text, settings.DEFAULT_FROM_EMAIL, [recipient], fail_silently=False)


def save_upload(f, folder):
    if not f or not f.size or f.size > MAX_FILE_SIZE:
        raise ValueError('Choose a file smaller than 25 MB.')
    ext = Path(f.name).suffix.lower()
    if ext not in FILE_TYPES:
        raise ValueError('Unsupported file type. Use PDF, Office, text, image or MP4 files.')
    safe_folder = {'materials', 'submissions'}
    if folder not in safe_folder:
        raise ValueError('Invalid upload destination.')
    dest_dir = settings.MEDIA_ROOT / folder
    dest_dir.mkdir(parents=True, exist_ok=True)
    rel = f'{folder}/{uuid.uuid4().hex}{ext}'
    with (settings.MEDIA_ROOT / rel).open('wb') as out:
        for chunk in f.chunks():
            out.write(chunk)
    return {'path': rel, 'name': get_valid_filename(Path(f.name).name), 'size': f.size}


def attachment_response(ref):
    if not isinstance(ref, dict) or not ref.get('path'):
        raise Http404()
    filename = (settings.MEDIA_ROOT / ref['path']).resolve()
    if settings.MEDIA_ROOT.resolve() not in filename.parents or not filename.is_file():
        raise Http404()
    return FileResponse(filename.open('rb'), as_attachment=True, filename=ref.get('name', 'attachment'))


def home(request):
    courses = [course_enriched(x) for x in col('courses').find({'status': 'published'}).sort('created_at', -1).limit(3)]
    stats = {'courses': col('courses').count_documents({'status': 'published'}), 'students': col('users').count_documents({'role': 'student', 'active': True})}
    return render_page(request, 'home.html', featured=courses, stats=stats)


def catalog(request):
    q = request.GET.get('q', '')[:90].strip()
    programme = request.GET.get('programme', '')[:80]
    field = request.GET.get('field', '')[:80]
    semester = request.GET.get('semester', '')[:40]
    query = {'status': 'published'}
    if q:
        rx = safe_search(q)
        query['$or'] = [{'title': {'$regex': rx, '$options': 'i'}}, {'description': {'$regex': rx, '$options': 'i'}}, {'tags': {'$regex': rx, '$options': 'i'}}]
    if programme:
        query['programme'] = programme
    if field:
        query['field'] = field
    if semester:
        query['semester'] = semester
    courses = [course_enriched(x) for x in col('courses').find(query).sort('created_at', -1).limit(100)]
    return render_page(request, 'catalog.html', courses=courses, q=q, chosen_programme=programme,
                       chosen_field=field, chosen_semester=semester,
                       programmes=sorted(col('courses').distinct('programme', {'status': 'published'})),
                       fields=sorted(col('courses').distinct('field', {'status': 'published'})),
                       semesters=sorted(col('courses').distinct('semester', {'status': 'published'})))


def course_detail(request, course_id):
    course = get_one('courses', course_id)
    if not can_view_course(request, course):
        raise Http404()
    row = course_enriched(course)
    my_enrolment = enrolled(request, course_id)
    assignments = clean_list(col('assignments').find({'course_id': oid(course_id)}).sort('due_at', 1))
    return render_page(request, 'course_detail.html', course=row, my_enrolment=clean(my_enrolment),
                       assignments=assignments, is_manager=manages(request, course))


@require_GET
def availability(request, course_id):
    course = get_one('courses', course_id, status='published')
    seats = max(0, int(course.get('capacity', 0)) - occupancy(course_id))
    response = JsonResponse({'remaining': seats, 'available': seats > 0})
    response['Cache-Control'] = 'no-store'
    return response


def create_enrolment(request, course, paid=0, promo=None):
    if occupancy(str(course['_id'])) >= int(course.get('capacity', 0)):
        messages.error(request, 'This course is currently full.')
        return redirect('course_detail', course_id=str(course['_id']))
    row = {'student_id': oid(request.user_doc['id']), 'course_id': course['_id'], 'status': 'active',
           'created_at': now(), 'completed_modules': [], 'messages': [], 'notifications': [],
           'payment': {'mode': 'demo', 'amount': float(money(paid)), 'currency': settings_doc().get('currency', 'MUR'),
                       'promo_code': promo, 'reference': f'DEMO-{uuid.uuid4().hex[:10].upper()}'}}
    try:
        col('enrolments').insert_one(row)
    except DuplicateKeyError:
        messages.info(request, 'You are already enrolled in this course.')
        return redirect('learning', course_id=str(course['_id']))
    messages.success(request, 'Enrolment confirmed. Your course is ready!')
    return redirect('learning', course_id=str(course['_id']))


@require_POST
@roles('student')
def enrol(request, course_id):
    course = get_one('courses', course_id, status='published')
    if money(course.get('price')) > 0:
        return redirect('checkout', course_id=course_id)
    return create_enrolment(request, course)


@roles('student')
def checkout(request, course_id):
    course = get_one('courses', course_id, status='published')
    if enrolled(request, course_id):
        return redirect('learning', course_id=course_id)
    site = settings_doc()
    if not site.get('payments_enabled'):
        return HttpResponseForbidden('Demo checkout is disabled by the institution.')
    price = money(course.get('price', 0))
    if price <= 0:
        return redirect('course_detail', course_id=course_id)
    coupon = request.POST.get('promo', '').strip().upper()[:40] if request.method == 'POST' else ''
    valid_coupon = bool(coupon and coupon == str(site.get('promo_code', '')).upper())
    discount = int(site.get('promo_discount', 10)) if valid_coupon else 0
    due = (price * (Decimal(100-discount) / Decimal(100))).quantize(Decimal('.01'))
    if request.method == 'POST':
        if coupon and not valid_coupon:
            messages.error(request, 'This promo code is not valid.')
        elif request.POST.get('action') == 'pay':
            # No card numbers are collected: clearly marked simulated payment.
            return create_enrolment(request, course, paid=due, promo=coupon if valid_coupon else None)
    return render_page(request, 'checkout.html', course=course_enriched(course), price=price,
                       discount=discount, due=due, promo=coupon, valid_coupon=valid_coupon)


def signup(request):
    if request.user_doc:
        return redirect('dashboard')
    if request.method == 'POST':
        name = request.POST.get('name', '').strip()[:100]
        email = request.POST.get('email', '').strip().lower()[:254]
        password = request.POST.get('password', '')
        if len(name) < 2 or not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', email) or len(password) < 10:
            messages.error(request, 'Enter your name, valid email, and a password of at least 10 characters.')
        else:
            try:
                result = col('users').insert_one({'name': name, 'email': email, 'password_hash': make_password(password),
                    'role': 'student', 'active': True, 'joined_at': now()})
                request.session.cycle_key()
                request.session['user_id'] = str(result.inserted_id)
                messages.success(request, 'Welcome to Open Campus!')
                return redirect('dashboard')
            except DuplicateKeyError:
                messages.error(request, 'An account with this email already exists.')
    return render_page(request, 'auth.html', mode='signup')


def login(request):
    if request.user_doc:
        return redirect('dashboard')
    if request.method == 'POST':
        email = request.POST.get('email', '').strip().lower()[:254]
        password = request.POST.get('password', '')
        key = 'login_fail:' + __import__('hashlib').sha256((email + '|' + request.META.get('REMOTE_ADDR', '')).encode()).hexdigest()
        failures = cache.get(key, 0)
        if failures >= 8:
            messages.error(request, 'Too many attempts. Try again in 15 minutes.')
        else:
            user = col('users').find_one({'email': email, 'active': True})
            if user and check_password(password, user['password_hash']):
                cache.delete(key)
                request.session.cycle_key()
                request.session['user_id'] = str(user['_id'])
                return redirect('dashboard')
            cache.set(key, failures + 1, timeout=900)
            messages.error(request, 'Incorrect email or password.')
    return render_page(request, 'auth.html', mode='login')


@require_POST
@login_required
def logout(request):
    request.session.flush()
    return redirect('home')


@login_required
def dashboard(request):
    user = request.user_doc
    if user['role'] == 'administrator':
        return redirect('control')
    if user['role'] == 'lecturer':
        return redirect('lecturer')
    enrolments = list(col('enrolments').find({'student_id': oid(user['id']), 'status': 'active'}).sort('created_at', -1))
    courses = []
    grades = []
    for enrolment in enrolments:
        course = col('courses').find_one({'_id': enrolment['course_id']})
        if not course:
            continue
        item = course_enriched(course)
        total = len(item.get('modules', []))
        item['progress'] = round(100 * len(enrolment.get('completed_modules', [])) / total) if total else 0
        item['unread_count'] = sum(not n.get('read', False) for n in enrolment.get('notifications', []))
        courses.append(item)
    submissions = list(col('submissions').find({'student_id': oid(user['id'])}).sort('submitted_at', -1))
    for sub in submissions:
        grade = col('grades').find_one({'submission_id': sub['_id']})
        if grade:
            course = col('courses').find_one({'_id': sub['course_id']})
            grades.append({'course': course['title'] if course else 'Course', 'score': grade['score'],
                           'feedback': grade.get('feedback'), 'title': sub.get('title', 'Assessment')})
    deadlines = []
    for item in courses:
        for assignment_row in col('assignments').find({'course_id': oid(item['id']), 'due_at': {'$gte': now()}}).sort('due_at', 1):
            deadlines.append({'title': assignment_row['title'], 'due_at': assignment_row['due_at'], 'course': item})
    deadlines.sort(key=lambda x: x['due_at'])
    all_notifications = [n for e in enrolments for n in e.get('notifications', [])][-8:]
    return render_page(request, 'dashboard.html', courses=courses, grades=grades[:5], deadlines=deadlines[:4],
                       notifications=list(reversed(all_notifications)), total_courses=len(courses),
                       avg_progress=round(sum(c['progress'] for c in courses)/len(courses)) if courses else 0)


@roles('student', 'lecturer', 'administrator')
def learning(request, course_id):
    course = get_one('courses', course_id)
    manager = manages(request, course)
    enrolment = enrolled(request, course_id)
    if not manager and not enrolment:
        return HttpResponseForbidden('Enrol in this course to view its learning materials.')
    row = course_enriched(course)
    completed = list(enrolment.get('completed_modules', [])) if enrolment else []
    assignments = clean_list(col('assignments').find({'course_id': oid(course_id)}).sort('due_at', 1))
    submissions = {str(s['assignment_id']): clean(s) for s in col('submissions').find({'student_id': oid(request.user_doc['id']), 'course_id': oid(course_id), 'kind': 'assignment'})} if enrolment else {}
    for a in assignments:
        a['submission'] = submissions.get(a['id'])
    return render_page(request, 'learning.html', course=row, enrolment=clean(enrolment),
                       completed=completed, assignments=assignments, is_manager=manager)


@require_POST
@roles('student')
def complete_module(request, course_id):
    enrolment = enrolled(request, course_id)
    if not enrolment:
        return HttpResponseForbidden()
    course = get_one('courses', course_id)
    module_id = request.POST.get('module_id', '')
    if module_id not in [m.get('id') for m in course.get('modules', [])]:
        return HttpResponseBadRequest('Unknown module')
    col('enrolments').update_one({'_id': enrolment['_id']}, {'$addToSet': {'completed_modules': module_id}})
    messages.success(request, 'Module marked as completed.')
    return redirect('learning', course_id=course_id)


@roles('student', 'lecturer', 'administrator')
def download_material(request, course_id, material_id):
    course = get_one('courses', course_id)
    if not manages(request, course) and not enrolled(request, course_id):
        return HttpResponseForbidden()
    for module in course.get('modules', []):
        for item in module.get('materials', []):
            if item.get('id') == material_id:
                return attachment_response(item)
    raise Http404()


@roles('student', 'lecturer', 'administrator')
def assignment(request, course_id, assignment_id):
    course = get_one('courses', course_id)
    a = get_one('assignments', assignment_id, course_id=oid(course_id))
    manager = manages(request, course)
    enrolment = enrolled(request, course_id)
    if not manager and not enrolment:
        return HttpResponseForbidden()
    existing = col('submissions').find_one({'student_id': oid(request.user_doc['id']), 'assignment_id': a['_id']}) if enrolment else None
    if request.method == 'POST':
        if not enrolment:
            return HttpResponseForbidden()
        if now() > a['due_at']:
            messages.error(request, 'The submission deadline has passed.')
        elif existing:
            messages.error(request, 'You have already submitted this assignment.')
        else:
            try:
                uploaded = save_upload(request.FILES.get('work'), 'submissions')
                result = col('submissions').insert_one({'course_id': oid(course_id), 'assignment_id': a['_id'],
                    'student_id': oid(request.user_doc['id']), 'kind': 'assignment', 'title': a['title'],
                    'note': request.POST.get('note', '').strip()[:3000], 'file': uploaded, 'submitted_at': now()})
                email_notice('Assignment submission confirmed',
                             f'We received your submission for {a["title"]}. Reference: {result.inserted_id}', request.user_doc['email'])
                messages.success(request, 'Submitted successfully. A confirmation email has been generated.')
                return redirect('assignment', course_id=course_id, assignment_id=assignment_id)
            except ValueError as ex:
                messages.error(request, str(ex))
            except DuplicateKeyError:
                messages.error(request, 'An assignment submission already exists.')
    return render_page(request, 'assignment.html', course=course_enriched(course), assignment=clean(a),
                       submission=clean(existing), is_manager=manager, past_due=now() > a['due_at'])


@roles('student', 'lecturer', 'administrator')
def quiz(request, course_id, quiz_id):
    course = get_one('courses', course_id)
    if not settings_doc().get('quizzes_enabled'):
        return HttpResponseForbidden('Quizzes are disabled.')
    manager = manages(request, course)
    enrolment = enrolled(request, course_id)
    if not manager and not enrolment:
        return HttpResponseForbidden()
    quiz_doc = next((q for q in course.get('quizzes', []) if q['id'] == quiz_id), None)
    if not quiz_doc:
        raise Http404()
    existing = col('submissions').find_one({'student_id': oid(request.user_doc['id']), 'quiz_id': quiz_id, 'course_id': oid(course_id)}) if enrolment else None
    existing_grade = col('grades').find_one({'submission_id': existing['_id']}) if existing else None
    if request.method == 'POST':
        if not enrolment or existing:
            return HttpResponseForbidden('This quiz has already been completed or you are not enrolled.')
        questions = quiz_doc.get('questions', [])
        if not questions:
            return HttpResponseBadRequest('No questions in this quiz.')
        answers = [request.POST.get(f'q{i}', '') for i in range(len(questions))]
        if any(not a for a in answers):
            messages.error(request, 'Please answer every question.')
        else:
            correct = sum(answer == question['answer'] for answer, question in zip(answers, questions))
            score = round(100*correct/len(questions))
            try:
                result = col('submissions').insert_one({'student_id': oid(request.user_doc['id']),
                    'course_id': oid(course_id), 'quiz_id': quiz_id, 'kind': 'quiz',
                    'title': quiz_doc['title'], 'submitted_at': now(), 'answers': answers})
                col('grades').insert_one({'submission_id': result.inserted_id, 'student_id': oid(request.user_doc['id']),
                    'course_id': oid(course_id), 'score': score, 'feedback': f'{correct} of {len(questions)} correct',
                    'graded_at': now(), 'graded_by': 'automatic'})
                messages.success(request, 'Quiz completed. Your result is available below.')
                return redirect('quiz', course_id=course_id, quiz_id=quiz_id)
            except DuplicateKeyError:
                messages.error(request, 'You have already completed this quiz.')
    # Never send answer keys to student templates.
    shown_quiz = {**quiz_doc, 'questions': [{k:v for k,v in q.items() if k != 'answer'} for q in quiz_doc.get('questions', [])]}
    return render_page(request, 'quiz.html', course=course_enriched(course), quiz=shown_quiz,
                       grade=clean(existing_grade), submission=clean(existing), is_manager=manager)


def user_for_id(user_id):
    return col('users').find_one({'_id': oid(user_id)})


@roles('student', 'lecturer', 'administrator')
def conversation(request, course_id):
    if not settings_doc().get('messages_enabled'):
        return HttpResponseForbidden('Messaging is disabled.')
    course = get_one('courses', course_id)
    manager = manages(request, course)
    if manager:
        all_enrolments = list(col('enrolments').find({'course_id': course['_id'], 'status': 'active'}))
        picked = request.GET.get('student', '') or request.POST.get('student', '')
        thread = next((e for e in all_enrolments if str(e['student_id']) == picked), None)
    else:
        all_enrolments = []
        thread = enrolled(request, course_id)
        if not thread:
            return HttpResponseForbidden()
    if request.method == 'POST':
        if not thread:
            return HttpResponseBadRequest('Select a student conversation first.')
        body = request.POST.get('body', '').strip()[:2000]
        if body:
            col('enrolments').update_one({'_id': thread['_id']}, {'$push': {'messages': {
                'id': uuid.uuid4().hex[:12], 'author': request.user_doc['name'],
                'author_id': request.user_doc['id'], 'body': body, 'sent_at': now()
            }}})
            messages.success(request, 'Message sent.')
        target = f'/courses/{course_id}/messages/'
        if manager:
            target += f'?student={str(thread["student_id"])}'
        return redirect(target)
    students = []
    for e in all_enrolments:
        usr = col('users').find_one({'_id': e['student_id']}, {'name': 1, 'email': 1})
        if usr:
            students.append({'id': str(e['student_id']), 'name': usr['name'], 'email': usr['email']})
    return render_page(request, 'messages.html', course=course_enriched(course), students=students,
                       thread=clean(thread), is_manager=manager)


@require_POST
@roles('lecturer', 'administrator')
def announce(request, course_id):
    course = get_one('courses', course_id)
    if not manages(request, course) or not settings_doc().get('announcements_enabled'):
        return HttpResponseForbidden()
    title = request.POST.get('title', '').strip()[:120]
    body = request.POST.get('body', '').strip()[:2000]
    if title and body:
        col('courses').update_one({'_id': course['_id']}, {'$push': {'announcements': {
            '$each': [{'id': uuid.uuid4().hex[:12], 'title': title, 'body': body, 'created_at': now()}], '$position': 0}}})
        messages.success(request, 'Announcement published.')
    return redirect('learning', course_id=course_id)

@roles('lecturer', 'administrator')
def lecturer(request):
    user = request.user_doc
    query = {} if user['role'] == 'administrator' else {'lecturer_id': oid(user['id'])}
    courses = [course_enriched(x) for x in col('courses').find(query).sort('created_at', -1)]
    course_ids = [oid(c['id']) for c in courses]
    submissions = []
    if course_ids:
        for sub in col('submissions').find({'course_id': {'$in': course_ids}, 'kind': 'assignment'}).sort('submitted_at', -1).limit(30):
            student = col('users').find_one({'_id': sub['student_id']}, {'name': 1})
            course = next((c for c in courses if c['id'] == str(sub['course_id'])), None)
            grade = col('grades').find_one({'submission_id': sub['_id']})
            submissions.append({**clean(sub), 'student_name': student['name'] if student else 'Unknown',
                                'course_title': course['title'] if course else 'Course', 'grade': clean(grade)})
    return render_page(request, 'lecturer.html', courses=courses, submissions=submissions,
                       student_count=sum(c['enrolled_count'] for c in courses),
                       pending_count=sum(not s['grade'] for s in submissions))


def parse_modules(raw, existing):
    """One module per line: title | learning goal, preserving stable IDs when titles match."""
    lookup = {m.get('title', '').lower(): m for m in existing or []}
    modules = []
    for line in raw.splitlines()[:24]:
        if not line.strip():
            continue
        parts = line.split('|', 1)
        title = parts[0].strip()[:120]
        if not title:
            continue
        old = lookup.get(title.lower(), {})
        modules.append({'id': old.get('id', uuid.uuid4().hex[:10]), 'title': title,
                        'goal': parts[1].strip()[:300] if len(parts) > 1 else old.get('goal', ''),
                        'materials': old.get('materials', [])})
    return modules


@roles('lecturer', 'administrator')
def course_editor(request, course_id=None):
    course = get_one('courses', course_id) if course_id else None
    if course and not manages(request, course):
        return HttpResponseForbidden()
    if request.method == 'POST':
        title = request.POST.get('title', '').strip()[:120]
        description = request.POST.get('description', '').strip()[:1600]
        try:
            capacity = int(request.POST.get('capacity', '40'))
            price = money(request.POST.get('price', '0'))
        except (ValueError, ArithmeticError):
            capacity, price = -1, Decimal('-1')
        if not title or not description or not (1 <= capacity <= 10000) or not (0 <= price <= 1000000):
            messages.error(request, 'Provide a title, description, valid seat capacity and nonnegative price.')
        else:
            chosen_lecturer = oid(request.user_doc['id'])
            if request.user_doc['role'] == 'administrator' and request.POST.get('lecturer_id'):
                candidate = col('users').find_one({'_id': oid(request.POST['lecturer_id']), 'role': 'lecturer', 'active': True})
                if candidate:
                    chosen_lecturer = candidate['_id']
            data = {
                'title': title, 'description': description, 'short_description': description[:150],
                'programme': request.POST.get('programme', 'General')[:80],
                'field': request.POST.get('field', 'General')[:80],
                'semester': request.POST.get('semester', 'Semester 1')[:40],
                'level': request.POST.get('level', 'All levels')[:40],
                'capacity': capacity, 'price': float(price),
                'duration': request.POST.get('duration', '8 weeks')[:30],
                'art': request.POST.get('art', 'ocean') if request.POST.get('art') in ('ocean','amber','plum','sage','ink','coral') else 'ocean',
                'modules': parse_modules(request.POST.get('modules', ''), course.get('modules', []) if course else []),
                'lecturer_id': chosen_lecturer, 'updated_at': now(),
            }
            if course:
                col('courses').update_one({'_id': course['_id']}, {'$set': data})
                messages.success(request, 'Course updated successfully.')
                return redirect('learning', course_id=course_id)
            data.update({'created_at': now(), 'status': 'published', 'quizzes': [], 'announcements': [], 'tags': []})
            result = col('courses').insert_one(data)
            messages.success(request, 'Course published.')
            return redirect('learning', course_id=str(result.inserted_id))
    lecturers = clean_list(col('users').find({'role': 'lecturer', 'active': True}).sort('name', 1))
    modules_raw = '\n'.join(f"{m.get('title','')} | {m.get('goal','')}" for m in (course or {}).get('modules', []))
    return render_page(request, 'course_editor.html', course=clean(course), modules_raw=modules_raw, lecturers=lecturers)


@roles('lecturer', 'administrator')
def upload_material(request, course_id):
    course = get_one('courses', course_id)
    if not manages(request, course):
        return HttpResponseForbidden()
    if request.method == 'POST':
        module_id = request.POST.get('module_id', '')
        if module_id not in [m['id'] for m in course.get('modules', [])]:
            messages.error(request, 'Choose a module first.')
        else:
            try:
                f = save_upload(request.FILES.get('material'), 'materials')
                f.update({'id': uuid.uuid4().hex[:12], 'uploaded_at': now()})
                col('courses').update_one({'_id': course['_id'], 'modules.id': module_id},
                                          {'$push': {'modules.$.materials': f}})
                messages.success(request, 'Material added to the module.')
                return redirect('learning', course_id=course_id)
            except ValueError as ex:
                messages.error(request, str(ex))
    return render_page(request, 'material_upload.html', course=course_enriched(course))


@roles('lecturer', 'administrator')
def new_assignment(request, course_id):
    course = get_one('courses', course_id)
    if not manages(request, course):
        return HttpResponseForbidden()
    if request.method == 'POST':
        title = request.POST.get('title', '').strip()[:130]
        instructions = request.POST.get('instructions', '').strip()[:3000]
        try:
            due_at = datetime.fromisoformat(request.POST.get('due_at', '')).replace(tzinfo=ZoneInfo('Indian/Mauritius')).astimezone(timezone.utc)
        except ValueError:
            due_at = None
        if not title or not instructions or not due_at or due_at <= now():
            messages.error(request, 'Enter a title, instructions and a future deadline.')
        else:
            col('assignments').insert_one({'title': title, 'instructions': instructions, 'course_id': course['_id'],
                                           'due_at': due_at, 'created_at': now()})
            messages.success(request, 'Assignment published.')
            return redirect('learning', course_id=course_id)
    return render_page(request, 'assessment_editor.html', course=course_enriched(course), mode='assignment')


@roles('lecturer', 'administrator')
def new_quiz(request, course_id):
    course = get_one('courses', course_id)
    if not manages(request, course):
        return HttpResponseForbidden()
    if request.method == 'POST':
        title = request.POST.get('title', '').strip()[:120]
        question = request.POST.get('question', '').strip()[:500]
        options = [request.POST.get(f'option{i}', '').strip()[:200] for i in range(4)]
        answer = request.POST.get('answer', '')
        if not title or not question or any(not x for x in options) or answer not in options:
            messages.error(request, 'Complete the title, question, four options and a matching correct answer.')
        else:
            item = {'id': uuid.uuid4().hex[:12], 'title': title,
                    'questions': [{'prompt': question, 'options': options, 'answer': answer}]}
            col('courses').update_one({'_id': course['_id']}, {'$push': {'quizzes': item}})
            messages.success(request, 'Quiz created.')
            return redirect('learning', course_id=course_id)
    return render_page(request, 'assessment_editor.html', course=course_enriched(course), mode='quiz')


@roles('lecturer', 'administrator')
def grade_submission(request, submission_id):
    sub = get_one('submissions', submission_id, kind='assignment')
    course = get_one('courses', str(sub['course_id']))
    if not manages(request, course):
        return HttpResponseForbidden()
    student = user_for_id(str(sub['student_id']))
    grade = col('grades').find_one({'submission_id': sub['_id']})
    if request.method == 'POST':
        try:
            score = float(request.POST.get('score', ''))
        except ValueError:
            score = -1
        feedback = request.POST.get('feedback', '').strip()[:3000]
        if not (0 <= score <= 100) or not feedback:
            messages.error(request, 'Enter a score between 0 and 100 and constructive feedback.')
        else:
            col('grades').update_one({'submission_id': sub['_id']}, {'$set': {
                'student_id': sub['student_id'], 'course_id': sub['course_id'],
                'score': score, 'feedback': feedback, 'graded_at': now(),
                'graded_by': oid(request.user_doc['id'])}}, upsert=True)
            col('enrolments').update_one({'student_id': sub['student_id'], 'course_id': sub['course_id']},
                {'$push': {'notifications': {'title': f'Graded: {sub["title"]}',
                    'body': f'Your result is {score:g}%.', 'created_at': now(), 'read': False}}})
            email_notice('Your assignment has been graded',
                         f'{sub["title"]}: {score:g}%\nFeedback: {feedback}', student['email'] if student else None)
            messages.success(request, 'Grade and feedback saved. Student notification generated.')
            return redirect('lecturer')
    return render_page(request, 'grade.html', submission=clean(sub), grade=clean(grade),
                       course=course_enriched(course), student=clean(student))


@roles('lecturer', 'administrator')
def download_submission(request, submission_id):
    sub = get_one('submissions', submission_id, kind='assignment')
    course = get_one('courses', str(sub['course_id']))
    if not manages(request, course):
        return HttpResponseForbidden()
    return attachment_response(sub.get('file'))


@roles('administrator')
def control(request):
    recent = clean_list(col('courses').find().sort('created_at', -1).limit(8))
    for c in recent:
        c['enrolled_count'] = occupancy(c['id'])
    return render_page(request, 'control.html', courses=recent,
                       total_students=col('users').count_documents({'role': 'student', 'active': True}),
                       total_lecturers=col('users').count_documents({'role': 'lecturer', 'active': True}),
                       total_courses=col('courses').count_documents({'status': 'published'}),
                       total_enrolments=col('enrolments').count_documents({'status': 'active'}))


@roles('administrator')
def admin_users(request):
    users = clean_list(col('users').find({}, {'password_hash': 0}).sort('joined_at', -1))
    return render_page(request, 'admin_users.html', users=users)


@roles('administrator')
def admin_user_edit(request, user_id):
    user = get_one('users', user_id) if user_id != 'new' else None
    if request.method == 'POST':
        name = request.POST.get('name', '').strip()[:100]
        email = request.POST.get('email', '').strip().lower()[:254]
        role = request.POST.get('role', 'student')
        password = request.POST.get('password', '')
        if not name or not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', email) or role not in ('student', 'lecturer', 'administrator'):
            messages.error(request, 'Enter valid user details.')
        elif not user and len(password) < 10:
            messages.error(request, 'New users require a password of at least 10 characters.')
        elif password and len(password) < 10:
            messages.error(request, 'Passwords must contain at least 10 characters.')
        else:
            changes = {'name': name, 'email': email, 'role': role, 'active': request.POST.get('active') == 'on'}
            if password:
                changes['password_hash'] = make_password(password)
            try:
                if user:
                    if user['_id'] == oid(request.user_doc['id']) and (role != 'administrator' or not changes['active']):
                        return HttpResponseBadRequest('You cannot revoke your own administrator access.')
                    col('users').update_one({'_id': user['_id']}, {'$set': changes})
                else:
                    changes['joined_at'] = now()
                    col('users').insert_one(changes)
                messages.success(request, 'User saved.')
                return redirect('admin_users')
            except DuplicateKeyError:
                messages.error(request, 'This email is already in use.')
    data = clean(user)
    if data:
        data.pop('password_hash', None)
    return render_page(request, 'admin_user_edit.html', edited_user=data)


@require_POST
@roles('administrator')
def admin_user_delete(request, user_id):
    if user_id == request.user_doc['id']:
        return HttpResponseBadRequest('You cannot delete your own account.')
    user = get_one('users', user_id)
    # Block destructive removal of a lecturer's active assigned courses.
    if user['role'] == 'lecturer' and col('courses').count_documents({'lecturer_id': user['_id'], 'status': 'published'}):
        messages.error(request, 'Reassign or archive this lecturer’s published courses before deletion.')
    else:
        col('users').delete_one({'_id': user['_id']})
        messages.success(request, 'User deleted. Existing academic records remain for audit purposes.')
    return redirect('admin_users')


@require_POST
@roles('administrator')
def admin_course_archive(request, course_id):
    course = get_one('courses', course_id)
    next_status = 'published' if course.get('status') == 'archived' else 'archived'
    col('courses').update_one({'_id': course['_id']}, {'$set': {'status': next_status}})
    messages.success(request, f'Course {next_status}.')
    return redirect('control')


@require_POST
@roles('administrator')
def admin_course_delete(request, course_id):
    course = get_one('courses', course_id)
    # No dangling course-owned records. In production use a transaction + audit log.
    submissions = [s['_id'] for s in col('submissions').find({'course_id': course['_id']}, {'_id': 1})]
    if submissions:
        col('grades').delete_many({'submission_id': {'$in': submissions}})
    for collection in ('submissions', 'assignments', 'enrolments'):
        col(collection).delete_many({'course_id': course['_id']})
    col('courses').delete_one({'_id': course['_id']})
    messages.success(request, 'Course and related academic records deleted.')
    return redirect('control')


@require_POST
@roles('administrator')
def admin_unenrol(request, enrol_id):
    enrollment = get_one('enrolments', enrol_id)
    col('enrolments').update_one({'_id': enrollment['_id']}, {'$set': {'status': 'withdrawn'}})
    messages.success(request, 'Enrolment withdrawn.')
    return redirect('database_explorer')


@roles('administrator')
def admin_settings(request):
    if request.method == 'POST':
        accent = request.POST.get('accent', '#c95735')
        if not re.fullmatch(r'#[0-9a-fA-F]{6}', accent):
            accent = '#c95735'
        try:
            discount = int(request.POST.get('promo_discount', '10'))
        except ValueError:
            discount = 10
        settings_update = {
            'institution_name': request.POST.get('institution_name', 'Open University of Mauritius').strip()[:120],
            'platform_name': request.POST.get('platform_name', 'Open Campus').strip()[:50],
            'strapline': request.POST.get('strapline', '').strip()[:120],
            'accent': accent, 'promo_code': request.POST.get('promo_code', 'LEARN10').strip().upper()[:32],
            'promo_discount': max(0, min(50, discount)),
            'course_layout': 'standard',
            'payments_enabled': request.POST.get('payments_enabled') == 'on',
            'quizzes_enabled': request.POST.get('quizzes_enabled') == 'on',
            'announcements_enabled': request.POST.get('announcements_enabled') == 'on',
            'messages_enabled': request.POST.get('messages_enabled') == 'on',
        }
        col('settings').update_one({'_id': 'institution'}, {'$set': settings_update}, upsert=True)
        messages.success(request, 'Institution settings saved.')
        return redirect('admin_settings')
    return render_page(request, 'admin_settings.html', configuration=settings_doc())


# Field allowlist for safe, auditable administrative edits; never expose/edit hashes.
EDITABLE_FIELDS = {
    'users': ('name', 'email', 'role', 'active'),
    'courses': ('title', 'description', 'status', 'programme', 'field', 'semester', 'capacity', 'price', 'duration'),
    'enrolments': ('status', 'completed_modules'),
    'assignments': ('title', 'instructions'),
    'submissions': ('note',),
    'grades': ('score', 'feedback'),
}


def serializable(value):
    if isinstance(value, ObjectId):
        return str(value)
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, dict):
        return {k: serializable(v) for k,v in value.items() if k != 'password_hash'}
    if isinstance(value, list):
        return [serializable(v) for v in value]
    return value


@roles('administrator')
def database_explorer(request):
    name = request.GET.get('collection', 'enrolments')
    if name not in CORE_COLLECTIONS:
        name = 'enrolments'
    docs = [serializable(x) for x in col(name).find().limit(50)]
    # Show only safe summary fields; no raw messages, password hashes or personal file paths.
    summary_keys = {'users': ('name','email','role','active'), 'courses': ('title','programme','status','price'),
        'enrolments': ('student_id','course_id','status'), 'assignments': ('title','course_id','due_at'),
        'submissions': ('title','kind','student_id','submitted_at'), 'grades': ('score','feedback','graded_at')}
    rows = [{'id': d['_id'], 'summary': ' · '.join(f'{key}: {str(d.get(key,"—"))[:65]}' for key in summary_keys[name])} for d in docs]
    counts = {name: col(name).count_documents({}) for name in CORE_COLLECTIONS}
    return render_page(request, 'database.html', collection=name, rows=rows, counts=counts,
                       collections=CORE_COLLECTIONS)


@roles('administrator')
def database_record(request, collection, record_id):
    if collection not in EDITABLE_FIELDS:
        raise Http404()
    document = get_one(collection, record_id)
    editable = EDITABLE_FIELDS[collection]
    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'delete':
            if collection == 'users':
                return admin_user_delete(request, record_id)
            if collection == 'courses':
                return admin_course_delete(request, record_id)
            # Protect referential integrity for remaining records.
            if collection == 'submissions':
                col('grades').delete_many({'submission_id': document['_id']})
            if collection == 'assignments' and col('submissions').count_documents({'assignment_id': document['_id']}):
                messages.error(request, 'Cannot delete an assignment with submissions. Archive its course instead.')
                return redirect('database_record', collection=collection, record_id=record_id)
            col(collection).delete_one({'_id': document['_id']})
            messages.success(request, 'Record deleted.')
            return redirect('/control/database/?collection=' + collection)
        changes = {}
        for field in editable:
            raw = request.POST.get(field)
            if raw is None:
                continue
            old = document.get(field)
            if isinstance(old, bool):
                changes[field] = raw.lower() == 'true'
            elif isinstance(old, int) and not isinstance(old, bool):
                try:
                    changes[field] = int(raw)
                except ValueError:
                    return HttpResponseBadRequest('Invalid integer value')
            elif isinstance(old, float):
                try:
                    changes[field] = float(raw)
                except ValueError:
                    return HttpResponseBadRequest('Invalid numerical value')
            elif isinstance(old, list):
                try:
                    parsed = json.loads(raw)
                    if not isinstance(parsed, list):
                        raise ValueError()
                    changes[field] = parsed
                except (ValueError, json.JSONDecodeError):
                    return HttpResponseBadRequest('Invalid list JSON')
            else:
                changes[field] = raw[:3000]
        # Prevent privilege escalation through invalid role values and self-demotion.
        if collection == 'users':
            if changes.get('role', document.get('role')) not in ('student','lecturer','administrator'):
                return HttpResponseBadRequest('Invalid role')
            if record_id == request.user_doc['id'] and (changes.get('role', document.get('role')) != 'administrator' or changes.get('active', document.get('active')) is False):
                return HttpResponseBadRequest('Cannot revoke your own admin access')
        if collection == 'courses' and changes.get('status', document.get('status')) not in ('published', 'archived'):
            return HttpResponseBadRequest('Invalid course status')
        if collection == 'grades' and not 0 <= changes.get('score', document.get('score', 0)) <= 100:
            return HttpResponseBadRequest('Score must be between 0 and 100')
        try:
            col(collection).update_one({'_id': document['_id']}, {'$set': changes})
        except DuplicateKeyError:
            messages.error(request, 'Update conflicts with an existing unique record.')
        else:
            messages.success(request, 'Record updated.')
        return redirect('database_record', collection=collection, record_id=record_id)
    safe_document = serializable(document)
    safe_document['id'] = str(document['_id'])
    editable_values = [{'name': k, 'value': json.dumps(safe_document.get(k)) if isinstance(safe_document.get(k), list) else str(safe_document.get(k, '')), 'type': 'text'} for k in editable]
    return render_page(request, 'database_record.html', collection=collection,
                       record=safe_document, record_json=json.dumps(safe_document, indent=2, ensure_ascii=False),
                       editable=editable_values)
