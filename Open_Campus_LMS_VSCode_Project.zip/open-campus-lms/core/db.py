"""MongoDB access, ObjectId validation, indexes and serialization."""
import re
from functools import lru_cache
from datetime import datetime, timezone
from bson import ObjectId
from bson.errors import InvalidId
from django.conf import settings
from django.http import Http404
from pymongo import MongoClient, ASCENDING

CORE_COLLECTIONS = ('users', 'courses', 'enrolments', 'assignments', 'submissions', 'grades')
ALL_COLLECTIONS = CORE_COLLECTIONS + ('settings',)

@lru_cache(maxsize=1)
def client():
    return MongoClient(settings.MONGO_URI, serverSelectionTimeoutMS=3500)

def db():
    return client()[settings.MONGO_DB]

def col(name):
    if name not in ALL_COLLECTIONS:
        raise ValueError('Unknown collection')
    return db()[name]

def oid(s):
    try:
        return ObjectId(str(s))
    except (InvalidId, TypeError):
        raise Http404('Invalid identifier')

def get_one(name, identifier, **kwargs):
    result = col(name).find_one({'_id': oid(identifier), **kwargs})
    if not result:
        raise Http404('Record not found')
    return result

def now():
    return datetime.now(timezone.utc)

def clean(doc):
    """Return a Mongo document with template-friendly string IDs."""
    if doc is None:
        return None
    result = dict(doc)
    if '_id' in result:
        result['id'] = str(result['_id'])
    for key, val in list(result.items()):
        if isinstance(val, ObjectId):
            result[key] = str(val)
    return result

def clean_list(rows):
    return [clean(r) for r in rows]

def settings_doc():
    defaults = {
        '_id': 'institution', 'institution_name': 'Open University of Mauritius',
        'platform_name': 'Open Campus', 'strapline': 'Learning that moves with you.',
        'accent': '#c95735', 'promo_code': 'LEARN10', 'promo_discount': 10,
        'payments_enabled': True, 'quizzes_enabled': True,
        'announcements_enabled': True, 'messages_enabled': True,
        'course_layout': 'standard', 'currency': 'MUR',
    }
    row = col('settings').find_one({'_id': 'institution'})
    return {**defaults, **(row or {})}

def ensure_indexes():
    col('users').create_index([('email', ASCENDING)], unique=True)
    col('courses').create_index([('status', ASCENDING), ('programme', ASCENDING)])
    col('enrolments').create_index([('student_id', ASCENDING), ('course_id', ASCENDING)], unique=True)
    col('assignments').create_index([('course_id', ASCENDING), ('due_at', ASCENDING)])
    col('submissions').create_index([('student_id', ASCENDING), ('assignment_id', ASCENDING)], unique=True, partialFilterExpression={'assignment_id': {'$exists': True}})
    col('submissions').create_index([('student_id', ASCENDING), ('course_id', ASCENDING), ('quiz_id', ASCENDING)], unique=True, partialFilterExpression={'quiz_id': {'$exists': True}})
    col('grades').create_index([('submission_id', ASCENDING)], unique=True)
    col('settings').update_one({'_id': 'institution'}, {'$setOnInsert': {k:v for k,v in settings_doc().items() if k != '_id'}}, upsert=True)

def safe_search(q):
    return re.escape(str(q or '')[:90])
