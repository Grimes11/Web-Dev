"""Django integration tests, using an in-memory MongoDB substitute.
Run: pip install -r requirements-dev.txt && python manage.py test core -v 2
The test runner creates an isolated SQLite test database for Django sessions.
"""
from datetime import timedelta
from unittest.mock import patch
import mongomock
from django.contrib.auth.hashers import make_password
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase, override_settings
from core.db import col, now

@override_settings(EMAIL_BACKEND='django.core.mail.backends.locmem.EmailBackend')
class LMSWorkflowTests(TestCase):
    def setUp(self):
        self.mongo = mongomock.MongoClient()
        self.patcher = patch('core.db.client', return_value=self.mongo)
        self.patcher.start()
        self.addCleanup(self.patcher.stop)
        col('users').create_index('email', unique=True)
        col('enrolments').create_index([('student_id',1),('course_id',1)], unique=True)
        self.student = col('users').insert_one({'name':'Student Demo','email':'student@example.test',
            'password_hash':make_password('StrongPass123!'),'role':'student','active':True,'joined_at':now()}).inserted_id
        self.lecturer = col('users').insert_one({'name':'Lecturer Demo','email':'lecturer@example.test',
            'password_hash':make_password('StrongPass123!'),'role':'lecturer','active':True,'joined_at':now()}).inserted_id
        self.admin = col('users').insert_one({'name':'Admin Demo','email':'admin@example.test',
            'password_hash':make_password('StrongPass123!'),'role':'administrator','active':True,'joined_at':now()}).inserted_id
        self.course = col('courses').insert_one({'title':'Data Literacy','description':'Make decisions with data',
            'short_description':'Make decisions with data','programme':'Technology','field':'Analytics',
            'semester':'Semester 1','price':1000.0,'duration':'8 weeks','level':'Beginner',
            'art':'ocean','capacity':12,'lecturer_id':self.lecturer,'status':'published','created_at':now(),
            'modules':[{'id':'first','title':'Module 1','goal':'Understand data','materials':[]}],
            'quizzes':[{'id':'quiz1','title':'Warm up','questions':[{'prompt':'2+2?',
            'options':['1','2','3','4'],'answer':'4'}]}],'announcements':[]}).inserted_id
        self.assignment = col('assignments').insert_one({'course_id':self.course,'title':'Reflection',
            'instructions':'Write a short reflection','due_at':now()+timedelta(days=2)}).inserted_id

    def signin(self, role='student'):
        res = self.client.post('/login/', {'email':f'{role}@example.test','password':'StrongPass123!'})
        self.assertEqual(res.status_code, 302)

    def test_signup_can_only_create_student(self):
        res = self.client.post('/signup/', {'name':'New Student','email':'new@example.test',
                                          'password':'StrongPass123!', 'role':'administrator'})
        self.assertEqual(res.status_code, 302)
        self.assertEqual(col('users').find_one({'email':'new@example.test'})['role'], 'student')

    def test_student_cannot_view_admin_console(self):
        self.signin()
        self.assertEqual(self.client.get('/control/').status_code, 403)
        self.assertEqual(self.client.get('/control/database/').status_code, 403)

    def test_guest_cannot_view_materials(self):
        response = self.client.get(f'/learn/{self.course}/')
        self.assertEqual(response.status_code, 302)

    def test_coupon_applied_on_server_and_enrolment_created(self):
        self.signin()
        res = self.client.post(f'/courses/{self.course}/checkout/', {'promo':'LEARN10', 'action':'pay'})
        self.assertEqual(res.status_code, 302)
        doc = col('enrolments').find_one({'student_id':self.student,'course_id':self.course})
        self.assertEqual(doc['payment']['amount'], 900.0)
        self.assertEqual(doc['payment']['mode'], 'demo')

    def test_quiz_is_graded_automatically(self):
        self.signin()
        self.client.post(f'/courses/{self.course}/checkout/', {'promo':'','action':'pay'})
        res = self.client.post(f'/courses/{self.course}/quizzes/quiz1/', {'q0':'4'})
        self.assertEqual(res.status_code, 302)
        grade = col('grades').find_one({'student_id':self.student,'course_id':self.course})
        self.assertEqual(grade['score'], 100)
        self.assertEqual(self.client.post(f'/courses/{self.course}/quizzes/quiz1/', {'q0':'4'}).status_code, 403)

    def test_submission_and_lecturer_grading(self):
        from django.core import mail
        self.signin()
        self.client.post(f'/courses/{self.course}/checkout/', {'promo':'','action':'pay'})
        file = SimpleUploadedFile('reflection.txt', b'A short assignment.', content_type='text/plain')
        with self.settings(MEDIA_ROOT=self._test_media()):
            res = self.client.post(f'/courses/{self.course}/assignments/{self.assignment}/', {'note':'Here is my work', 'work': file})
            self.assertEqual(res.status_code, 302)
        submission = col('submissions').find_one({'student_id':self.student,'assignment_id':self.assignment})
        self.assertIsNotNone(submission)
        self.assertEqual(len(mail.outbox), 1)
        self.client.post('/logout/')
        self.signin('lecturer')
        res = self.client.post(f'/lecturer/submissions/{submission["_id"]}/grade/', {'score':'86', 'feedback':'Clear argument; add more examples.'})
        self.assertEqual(res.status_code, 302)
        self.assertEqual(col('grades').find_one({'submission_id':submission['_id']})['score'], 86.0)
        self.assertEqual(len(mail.outbox), 2)

    @staticmethod
    def _test_media():
        import tempfile
        from pathlib import Path
        # The temporary directory is removed with the process, not a production file store.
        return Path(tempfile.mkdtemp(prefix='open-campus-test-'))
