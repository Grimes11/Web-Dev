from .db import settings_doc

def site_context(request):
    return {'site': settings_doc(), 'current_user': getattr(request, 'user_doc', None)}
