from .db import col, oid, clean

class MongoCurrentUserMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        request.user_doc = None
        user_id = request.session.get('user_id')
        if user_id:
            try:
                row = col('users').find_one({'_id': oid(user_id), 'active': True})
                if row:
                    request.user_doc = clean(row)
                else:
                    request.session.flush()
            except Exception:
                # Fail closed on invalid session IDs, but do not conceal a Mongo outage.
                if len(str(user_id)) != 24:
                    request.session.flush()
                else:
                    raise
        return self.get_response(request)
