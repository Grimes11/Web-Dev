"""Seed realistic demo accounts, university courses and academic records.
Runs only when DEBUG=True, and is safe to re-run (no duplicate courses).
"""
from datetime import timedelta
from uuid import uuid4
from django.conf import settings
from django.contrib.auth.hashers import make_password
from django.core.management.base import BaseCommand, CommandError
from core.db import col, ensure_indexes, now

COURSES = [
    ('Digital Business & Innovation', 'Business Administration', 'Business', 'Semester 1', 'ocean', 0, '8 weeks',
     'Explore how technology changes organisations, industries and the way people work. Build a practical toolkit for digital-first business decisions.',
     [('The digital landscape', 'Understand digital transformation and value creation'), ('Business models that matter','Evaluate innovative service models'), ('Making strategy work','Design a realistic digital roadmap')],
     [('What is a key driver of digital innovation?', ['Avoiding feedback', 'Understanding customer needs', 'Ignoring data', 'Reducing collaboration'], 'Understanding customer needs')]),
    ('Introduction to Data Analytics', 'Information Technology', 'Technology', 'Semester 2', 'amber', 1500, '10 weeks',
     'Start making sense of data. Learn fundamentals of analysis, visual thinking and evidence-based decisions through applied examples.',
     [('Thinking with data','Identify useful questions and data sources'), ('Explore and understand','Describe trends and spot patterns'), ('Present insight clearly','Explain findings in context')],
     [('Which chart best shows a trend over time?', ['Pie chart', 'Line chart', 'Table without dates', 'Word cloud'], 'Line chart')]),
    ('Sustainable Development', 'Environmental Studies', 'Sustainability', 'Semester 1', 'sage', 0, '6 weeks',
     'Discover the systems, ideas and actions behind sustainable development, from local communities to global challenges.',
     [('Principles of sustainability','Connect environmental, social and economic dimensions'), ('The local perspective','Understand sustainability in island states'), ('Practical action','Build an evidence-based sustainability plan')],
     [('Which is a dimension of sustainability?', ['Social wellbeing', 'Only marketing', 'Only profit', 'None of these'], 'Social wellbeing')]),
    ('The Psychology of Learning', 'Education', 'Education', 'Semester 2', 'plum', 1200, '8 weeks',
     'Learn how memory, motivation and attention shape the learning experience and how to apply research to your everyday study habits.',
     [('How we learn','Examine memory and attention'), ('Motivation in practice','Build effective study routines'), ('Reflect and improve','Apply evidence-based learning strategies')],
     [('What strengthens long-term learning?', ['Spaced practice', 'Never reviewing', 'Only cramming', 'Avoiding recall'], 'Spaced practice')]),
    ('Foundations of Cybersecurity', 'Information Technology', 'Technology', 'Semester 1', 'ink', 1800, '9 weeks',
     'A practical introduction to personal and organisational security, risk awareness and protective digital habits.',
     [('Security fundamentals','Recognise common threats'), ('Protecting systems','Learn defence-in-depth principles'), ('Incident thinking','Respond responsibly to suspected breaches')],
     [('Which helps protect an account?', ['Reusing passwords', 'Multi-factor authentication', 'Sharing OTP codes', 'Disabling updates'], 'Multi-factor authentication')]),
    ('Communication for Professionals', 'Communication Studies', 'Humanities', 'Semester 2', 'coral', 0, '5 weeks',
     'Communicate ideas with clarity and confidence through writing, presentations and thoughtful collaboration.',
     [('Find your voice','Create an effective message'), ('Present ideas','Structure compelling presentations'), ('Listen and collaborate','Practice constructive communication')],
     [('What supports effective communication?', ['Active listening', 'Interrupting', 'Avoiding feedback', 'Vague language'], 'Active listening')]),
]

class Command(BaseCommand):
    help = 'Populate MongoDB with a complete fictional university demonstration dataset.'

    def handle(self, *args, **options):
        if not settings.DEBUG:
            raise CommandError('Demo data seeding is only allowed with DEBUG=True.')
        try:
            ensure_indexes()
            users = [
                ('Amelia Admin', 'admin@campus.test', 'administrator'),
                ('Dr Maya Laurent', 'lecturer@campus.test', 'lecturer'),
                ('Prof Daniel Wong', 'lecturer2@campus.test', 'lecturer'),
                ('Alex Morgan', 'student@campus.test', 'student'),
            ]
            ids = {}
            for name, email, role in users:
                result = col('users').find_one_and_update({'email': email}, {'$setOnInsert': {
                    'name': name, 'email': email, 'role': role,
                    'password_hash': make_password('DemoPass123!'), 'active': True, 'joined_at': now()}}, upsert=True, return_document=True)
                ids[email] = result['_id']
            for i, (title, programme, field, semester, art, price, duration, description, modules, question) in enumerate(COURSES):
                course_doc = col('courses').find_one({'title': title})
                if course_doc:
                    continue
                content = [{'id': uuid4().hex[:10], 'title': item[0], 'goal': item[1], 'materials': []} for item in modules]
                prompt, opts, answer = question[0]
                doc = {'title': title, 'description': description, 'short_description': description[:150],
                       'programme': programme, 'field': field, 'semester': semester, 'level': 'Beginner friendly',
                       'art': art, 'price': float(price), 'capacity': 45+i*10, 'duration': duration,
                       'lecturer_id': ids['lecturer@campus.test'] if i%2 == 0 else ids['lecturer2@campus.test'],
                       'status': 'published', 'tags': [field.lower(), programme.lower()], 'modules': content,
                       'quizzes': [{'id': uuid4().hex[:12], 'title': 'Understanding the essentials',
                                    'questions': [{'prompt': prompt, 'options': opts, 'answer': answer}]}],
                       'announcements': [{'id': uuid4().hex[:12], 'title': 'Welcome to the course!',
                                          'body': 'Start with Module 01 and explore the material at your own pace.', 'created_at': now()}],
                       'created_at': now()-timedelta(days=i), 'updated_at': now()}
                result = col('courses').insert_one(doc)
                col('assignments').insert_one({'title': 'Your first applied reflection',
                    'instructions': 'In 500–800 words, explain a key concept from the course and how you might apply it in practice. Include concrete examples.',
                    'course_id': result.inserted_id, 'due_at': now()+timedelta(days=14+i), 'created_at': now()})
            first = col('courses').find_one({'title': 'Digital Business & Innovation'})
            col('enrolments').update_one({'student_id': ids['student@campus.test'], 'course_id': first['_id']}, {'$setOnInsert': {
                'student_id': ids['student@campus.test'], 'course_id': first['_id'], 'status': 'active',
                'completed_modules': [first['modules'][0]['id']], 'created_at': now()-timedelta(days=3),
                'messages': [], 'notifications': [], 'payment': {'mode': 'demo', 'amount': 0, 'currency': 'MUR', 'reference': 'DEMO-SEED'}}}, upsert=True)
            self.stdout.write(self.style.SUCCESS('Demo seeded successfully. Sign in with any @campus.test account and DemoPass123!'))
        except Exception as err:
            raise CommandError(f'Could not connect to MongoDB: {err}') from err
