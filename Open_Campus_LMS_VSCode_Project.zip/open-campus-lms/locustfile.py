"""Lightweight load test (public read paths only). Use against isolated test data."""
from locust import HttpUser, task, between

class CatalogVisitor(HttpUser):
    wait_time = between(1, 3)

    @task(3)
    def home(self):
        self.client.get('/')

    @task(6)
    def catalog(self):
        self.client.get('/courses/')

    @task(2)
    def search(self):
        self.client.get('/courses/?q=data')
