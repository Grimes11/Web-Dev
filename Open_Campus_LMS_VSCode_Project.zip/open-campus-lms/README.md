# Open Campus LMS

A premium, responsive, framework-free HTML/CSS/JavaScript frontend backed by Python/Django and MongoDB (PyMongo). An **independent educational case study** using the Open University of Mauritius as the scenario; **not an official service** of the university.

## Quick start in VS Code

Prerequisites: **Python 3.12+**, VS Code, and either **Docker Desktop** or a running MongoDB server on `localhost:27017`.

1. Open this folder in VS Code, then open **Terminal → New Terminal**.
2. Start MongoDB using `docker compose up -d` (or point `MONGO_URI` to an existing MongoDB instance).
3. Create and activate a Python virtual environment:

   ```bash
   python -m venv .venv
   # Windows PowerShell:
   .\.venv\Scripts\Activate.ps1
   # macOS / Linux:
   source .venv/bin/activate
   ```

4. Run `python -m pip install -r requirements.txt`.
5. Copy `.env.example` to `.env`, replacing `DJANGO_SECRET_KEY` with a long secret string. For the local demo, `DEBUG=True` is expected.
6. Run `python manage.py migrate --run-syncdb` to create Django's **SQLite session table**. All business records live in MongoDB.
7. Run `python manage.py seed_demo` to populate the database and indexes.
8. Run `python manage.py runserver` and visit **http://127.0.0.1:8000/**.

### Windows VS Code commands

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
# edit .env as needed
# start MongoDB with Docker Desktop: docker compose up -d
python manage.py migrate --run-syncdb
python manage.py seed_demo
python manage.py runserver
```

On Windows, choose `.venv\Scripts\python.exe` as the VS Code Python interpreter. On macOS/Linux, choose `.venv/bin/python`.

## Demo accounts (local only)

| Role | Email | Password |
|---|---|---|
| Administrator | `admin@campus.test` | `DemoPass123!` |
| Lecturer | `lecturer@campus.test` | `DemoPass123!` |
| Second lecturer | `lecturer2@campus.test` | `DemoPass123!` |
| Student | `student@campus.test` | `DemoPass123!` |

The seed command only works when `DEBUG=True`. **Never use these demo credentials or this dataset in a real deployment.**

## Workflows to try

- **Student:** log in → dashboard → catalog → free course enrolment, or paid course → `LEARN10` 10%-off code → *simulated* checkout. Open the course → mark a module complete → answer the quiz → submit assignment file → message your lecturer → view grades and notifications.
- **Lecturer:** log in → teaching overview → create/edit a course → edit modules → upload a protected PDF/video → add assignment and quiz → post an announcement → grade submitted work, adding feedback and notification.
- **Administrator:** log in → institution overview → manage users and roles → create/archive/delete courses → manage MongoDB academic records → change platform name, institution name, branding colour, promo codes and feature switches.

Assignment submission and grading call Django `send_mail`. The default **console** backend prints email contents in your terminal; set SMTP environment variables to send real email. SMTP was intentionally not tested or enabled in this demo.

## Architecture

```text
Browser (Django templates, vanilla HTML/CSS/JS, responsive)
        |
        v
Django URL routes -> view + authorization -> PyMongo -> MongoDB
        |                    |
        |                    +-> six academic collections + settings
        +-> Django sessions in SQLite (framework metadata only)
        +-> Email backend (console by default)
        +-> protected file downloads (local MEDIA_ROOT)
```

This is a deliberate hybrid: PyMongo controls the MongoDB domain objects while Django's session framework uses its own small SQLite store. MongoDB's official Django integration is currently in Public Preview; using direct PyMongo avoids relying on preview ORM behavior for the local case study.

**Six academic collections:** `users`, `courses`, `enrolments`, `assignments`, `submissions`, `grades`. **One additional configuration collection:** `settings`, which avoids storing institution-wide branding or promo codes in inappropriate academic records. Course modules, announcements and quizzes are embedded in `courses`. Course-specific messages and notifications are embedded in `enrolments`. Demo transaction references/discounts are stored under `enrolments.payment`.

MongoDB indexes are created by `seed_demo`. In a new production installation, call `ensure_indexes()` in an explicit migration/initialization command. Do not create indexes on each incoming request.

## Realistic scope and limitations

**Implemented for local proof of concept:** secured server-side roles, public course search and category filters, near-live capacity polling, student enrolment, paid course demo checkout, admin-configurable promo code with server-side discount calculation, per-course content/modules, restricted file upload/download, completion tracking, assignments, email confirmation via configured backend, lecturer grading and feedback, basic quizzes (one MCQ per newly created quiz, seeded examples), dashboards, announcements, per-course student–lecturer messages, settings and CRUD admin interface, responsive design, essential/optional consent choices, cacheable static assets and downloadable materials.

**Not implemented / not production ready:** real payment gateway/card processing; true mobile push notifications (VAPID/subscriptions/background worker); offline access to authenticated pages; advanced quiz builder, gradebook, invitation and password-recovery email flows; file malware scanning, audit logging, enterprise SSO, encrypted object storage, accessibility certification, end-to-end test suite, real-time seat reservation under high concurrency, and comprehensive regulatory/privacy compliance. These are important before institutional deployment.

**Security notes:** browser-supplied price/discount is never used; payment is simulated and no card fields exist. Passwords use Django's password hashing; signup creates students only, and course/grade/upload admin actions check role and course ownership on the server. CSRF tokens protect forms; uploads have extension and size constraints; media is served through authorized Django endpoints. Rate-limit for failed logins uses Django's local in-memory cache (single process only). Replace with Redis-backed rate limiting for distributed deployment. Course capacity checks can race under high concurrency and need an atomic reservation service if deployed. Django SQLite sessions are local-development only in this design; use a shared secure session store in production.

**Privacy:** The first-party banner offers essential-only consent by default, and this build includes no analytics/ads or third-party video trackers. `tarteaucitron.js` 1.37.0 is loaded from a pinned CDN and initialized when reachable, with the first-party banner as a graceful offline fallback. No third-party tracking services are registered yet; these must be configured individually when integrations are introduced. Consent alone is not a privacy compliance guarantee. Downloaded private course files remain on each student's device; static service worker does **not** cache private content.

### Privacy consent integration

`base.html` loads a pinned tarteaucitron.js release from jsDelivr and `static/js/site.js` initialises it. If the CDN is inaccessible, a local functional consent banner takes over. The build includes zero optional trackers; no analytics, ads or external embeds are loaded as a result of accepting consent. If you add YouTube, Google Analytics or other third-party services, register each using tarteaucitron services and check behavior under accept/reject; initializing the library alone does not block independently loaded scripts. For a fully offline deployment, vendor the library (including its CSS/language assets) locally. Official instructions: https://tarteaucitron.io/en/free-installation-open-source/ .

## Quality assurance

Run `python -m unittest discover -s tests -v` for the repository structure and parsing checks (these do not require Django/MongoDB). Run Django's built-in system checks after dependency installation: `python manage.py check`. The project includes a `locustfile.py` for read-only load tests: `locust -f locustfile.py --host=http://127.0.0.1:8000`. Test checkout, submissions, access control, email flow and concurrency manually in an isolated environment. A live Django + MongoDB integration test **has not been executed** in the supplied build environment.

## Suggested 12-week progression

| Weeks | Milestone |
|---|---|
| 1–2 | Research, UX structure, security model, Mongo design |
| 3–4 | Accounts, roles, course catalog, enrolment |
| 5–6 | Materials, assignments, grading and mail |
| 7–8 | Quiz tools, progress dashboard, announcements and messaging |
| 9–10 | Admin customisation, payment demo and privacy |
| 11–12 | Unit/integration/accessibility/load testing, polish and release readiness |

## Deployment note

Railway does have a Free plan, but its resources and monthly credits are limited; **do not assume truly free always-on production hosting**. See https://docs.railway.com/pricing/plans . For any public deployment, replace local media/session storage, configure secrets and HTTPS, use a hardened file scanning pipeline, and conduct a security and privacy review first.
